package com.nillanaudio.proeq;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.SeekBar;

public class MainActivity extends Activity {
    private final String[] bands = {"31 Hz", "62 Hz", "125 Hz", "250 Hz", "500 Hz", "1 kHz", "2 kHz", "4 kHz", "8 kHz", "16 kHz"};
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 20, 24, 28);
        root.setBackgroundColor(Color.rgb(18, 22, 30));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("NILLAN AUDIO\nPRO EQ");
        title.setTextSize(28);
        title.setTextColor(Color.rgb(75, 210, 190));
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 12, 0, 8);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("10-Band Equalizer • Prototipe");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 0, 0, 18);
        root.addView(subtitle);

        TextView notice = new TextView(this);
        notice.setText("PENTING: versi ini adalah prototipe tampilan. Slider belum memproses audio Brave. Android biasanya tidak mengizinkan aplikasi biasa menerapkan EQ ke audio aplikasi lain secara global.");
        notice.setTextColor(Color.WHITE);
        notice.setTextSize(14);
        notice.setBackgroundColor(Color.rgb(42, 49, 62));
        notice.setPadding(14, 14, 14, 14);
        root.addView(notice);

        addLabel(root, "PREAMP / MASTER");
        addSlider(root, "Preamp", 12);
        for (String band : bands) addSlider(root, band, 12);

        TextView footer = new TextView(this);
        footer.setText("NILLAN AUDIO • Proyek baru 1.0");
        footer.setTextColor(Color.GRAY);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, 22, 0, 4);
        root.addView(footer);
        setContentView(scroll);
    }
    private void addLabel(LinearLayout root, String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(Color.rgb(75, 210, 190));
        label.setTextSize(16);
        label.setPadding(0, 18, 0, 2);
        root.addView(label);
    }
    private void addSlider(LinearLayout root, String name, int start) {
        TextView label = new TextView(this);
        label.setText(name + ": 0 dB");
        label.setTextColor(Color.WHITE);
        label.setTextSize(15);
        root.addView(label);
        SeekBar bar = new SeekBar(this);
        bar.setMax(24);
        bar.setProgress(start);
        root.addView(bar);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) { label.setText(name + ": " + (p - 12) + " dB"); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
    }
}
