# NILLAN AUDIO PRO EQ — proyek Android baru

Paket ini berisi struktur proyek Android Java dan workflow GitHub Actions untuk membangun APK debug.

## Cara build
1. Unggah semua isi ZIP ke akar repositori GitHub baru (bukan mengunggah ZIP sebagai satu file).
2. Buka tab Actions dan jalankan `Build NILLAN AUDIO PRO EQ APK`.
3. Jika berhasil, buka hasil run dan unduh artifact `NILLAN-AUDIO-PRO-EQ-debug`.

## Batasan penting
Versi ini hanya prototipe antarmuka EQ 10-band. Slider belum memproses audio. Aplikasi Android biasa tidak dapat menerapkan EQ ke audio Brave atau semua aplikasi lain secara global tanpa dukungan sistem/akses audio yang sesuai.
